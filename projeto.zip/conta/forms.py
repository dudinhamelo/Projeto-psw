from django import forms
from .models import Aluno, Secratario, Personal
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User

class AlunoForm(forms.ModelForm):

    class Meta:
        model = Aluno
        fields = ['cpf', 'data_nascimento', 'matricula', 'horario_uso']

class UserForm(UserCreationForm):

    class Meta:
        model = User
        fields = ("username", "password1", "password2", "email", "first_name", "last_name")
    
class SecretarioForm(forms.ModelForm):

    class Meta:
        model = Secratario
        fields = ['cpf', 'data_nascimento', 'matricula']
        
class PersonalForm(forms.ModelForm):
    class Meta:
        model = Personal
        fields = ['cpf', 'data_nascimento', 'matricula', 'diploma']