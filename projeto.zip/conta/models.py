from django.db import models
from django.contrib.auth.models import User


class Secratario(models.Model):
    cpf = models.CharField(max_length=11)
    data_nascimento = models.DateField()
    matricula = models.CharField(max_length=15, null=True)
    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True)


class Aluno(models.Model):
    cpf = models.CharField(max_length=11)
    data_nascimento = models.DateField()
    matricula = models.CharField(max_length=15, null=True)
    horario_uso = models.TimeField()
    user = models.ForeignKey(User, on_delete=models.CASCADE , null=True)


class Personal(models.Model):
    cpf = models.CharField(max_length=11)
    data_nascimento = models.DateField()
    matricula = models.CharField(max_length=15, null=True)
    diploma = models.CharField(max_length=150)
    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True)


class UsuarioAvaliacaoFisica(models.Model):
    m_quadril = models.CharField(max_length=255)
    m_braco = models.CharField(max_length=255)
    m_coxa = models.CharField(max_length=255)
    m_busto = models.CharField(max_length=255)
    peso = models.CharField(max_length=255)
    p_gordura = models.CharField(max_length=255)
    data_medicao =models.CharField(max_length=255)

    usuario = models.ForeignKey(Aluno, on_delete=models.CASCADE, null=True)
    personal = models.ForeignKey(Personal, on_delete=models.CASCADE, null=True)