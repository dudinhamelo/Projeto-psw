from django.urls import path, include
from .views import criar_aluno, editar_aluno, login_conta, criar_secretario, criar_personal, list_aluno, excluir_aluno, list_personal, list_secratario

urlpatterns = [
    path('criar/', criar_aluno, name="criar-aluno"),
    path('editar/', editar_aluno, name="editar-aluno"),
    path('deletar/<int:aluno_id>/', excluir_aluno, name="deletar-aluno"),
    path('detalhe/<int:aluno_id>/', list_aluno, name="detalhe-aluno"),


    path('login/', login_conta, name="login-conta"),

    path('criar-secretario/', criar_secretario, name="criar-secretario" ),
    path('detalhe-secretario/<int:secratario_id>/', list_secratario, name="detalhe-secretario"),

    path('criar-personal/', criar_personal, name="criar-personal" ),
    path('detalhe-personal/<int:personal_id>/', list_personal, name="detalhe-personal")

    
]