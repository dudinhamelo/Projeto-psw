import re
from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import render
from .forms import AlunoForm, UserForm, SecretarioForm, PersonalForm
from django.contrib.auth.models import User
from .models import Aluno, Secratario
from django.contrib.auth.decorators import login_required
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from .models import Secratario, Personal


# Create your views here.
def criar_aluno(request):
    if request.method == "POST":
        formulario_aluno = AlunoForm(request.POST)
        formulario_user = UserForm(request.POST)
        if formulario_aluno.is_valid() and formulario_user.is_valid():
            s_formulario_user = formulario_user.save()
            s_formulario = formulario_aluno.save(commit=False)
            s_formulario.user_id = s_formulario_user.id 
            s_formulario.save()
            return HttpResponseRedirect('/')
        else:
            context = {
                'formulario_usuario': formulario_user,
                'formulario_aluno': formulario_aluno 
            }
            return render(request, 'conta/formulario.html', context)
                
    else:
        formulario_aluno = AlunoForm()
        formulario_user = UserForm()
        context = {
            'formulario_usuario': formulario_user,
            'formulario_aluno': formulario_aluno 
        }
        return render(request, 'conta/formulario.html', context)

@login_required
def editar_aluno(request):

    user = User.objects.get(id=request.user.id)
    print(request.user.id)

    aluno = Aluno.objects.get(user=user.id)

    
    if request.method == "POST":
        formulario_aluno = AlunoForm(request.POST, instance=aluno)
        formulario_user = UserForm(request.POST, instance=user)

        if formulario_aluno.is_valid() and formulario_user.is_valid():
            formulario_aluno.save()
            formulario_user.save()
                        
            return HttpResponseRedirect('/')
        else:
            context = {
                'formulario_usuario': formulario_user,
                'formulario_aluno': formulario_aluno
            }
            return render(request, 'conta/formulario.html', context)
                
    else:
        formulario_aluno = AlunoForm(instance=aluno)
        formulario_user = UserForm(instance=user)
        context = {
            'formulario_usuario': formulario_user,
            'formulario_aluno': formulario_aluno 
        }
        return render(request, 'conta/formulario.html', context)

def excluir_aluno(request, aluno_id):
    Aluno.objects.get(id=aluno_id).delete()
    return HttpResponse('Objeto deletado com sucesso')

def list_aluno(request, aluno_id):
    aluno = Aluno.objects.get(id=aluno_id)
    context = {'aluno':aluno}
    return render(request, 'conta/profile.html', context)

def login_conta(request):
    if request.method == 'POST':
        username = request.POST['username']
        paswd = request.POST['password']
        usuario = authenticate(request, username=username, password=paswd)
        if usuario is not None:
            login(request, usuario)
            return HttpResponseRedirect('/')
        else:
            return render(request, 'conta/login.html', {'error': 'houve um erro'})

    else:
        
        return render(request, 'conta/login.html')

def criar_secretario(request):
    if request.method == "POST":
        formulario_secratario = SecretarioForm(request.POST)
        if formulario_secratario.is_valid():
            
            formulario_secratario.save()
            return HttpResponseRedirect('/')
        else:
            context = {
                'formulario_secratario': formulario_secratario,
            }
            return render(request, 'conta/formulario-secretario.html', context)
                
    else:
        formulario_secratario = SecretarioForm()
        context = {
            'formulario_secretario': formulario_secratario
        }
        return render(request, 'conta/formulario-secretario.html', context)

@login_required
def criar_personal(request):
    if request.method == "POST":
        formulario_personal = PersonalForm(request.POST)
        if formulario_personal.is_valid():
            
            formulario_personal.save()
            return HttpResponseRedirect('/')
        else:
            context = {
                'formulario_personal': formulario_personal,
            }
            return render(request, 'conta/formulario-personal.html', context)
                
    else:
        formulario_personal = PersonalForm()
        context = {
            'formulario_personal': formulario_personal
        }
        return render(request, 'conta/formulario-personal.html', context)

def list_secratario(request, secretario_id):
    secretario = Secratario.objects.get(id=secretario_id)
    return render(request, 'list-secretario.html',{'secretario': secretario})


def list_personal(request, personal_id):
    personal = Personal.objects.get(id=personal_id)
    return render(request, 'list-personal.html',{'personal': personal})