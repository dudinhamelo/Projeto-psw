from ast import Eq
from django.shortcuts import render
from academia.models import Equipamentos, FichaTreino
from conta.models import Aluno
from .forms import EquipamentosForm, FichaForm
from django.http import HttpResponseRedirect
# Create your views here.
from django.contrib.auth.decorators import login_required

def criar_equipamentos(request):


    if request.method == "POST":
        formulario = EquipamentosForm(request.POST)
        if formulario.is_valid():
            
           

            formulario.save()
            return HttpResponseRedirect('/')
        else:
            context = {
                'formulario': formulario
            }
            return render(request, 'academia/formulario.html', context)
                
    else:
        formulario = EquipamentosForm
        context = {
            'formulario': formulario
        }
        return render(request, 'academia/formulario.html', context)
def list_equipamentos(request, equipamento_id):
    equ = Equipamentos.objects.get(id=equipamento_id)
    return render(request, 'academia/equipamento.html', {'equipamento': equ})


@login_required
def criar_ficha(request):
    aluno = Aluno.objects.get(user=request.user.id)
    if request.method == "POST":
        formulario = FichaForm(request.POST)
        if formulario.is_valid():
            
            s_formulario = formulario.save(commit=False)
            s_formulario.aluno_id = aluno.id
            s_formulario.save()
            return HttpResponseRedirect('/')
        else:
            context = {
                'formulario': formulario
            }
            return render(request, 'academia/formulario-ficha.html', context)
                
    else:
        formulario = FichaForm
        context = {
            'formulario': formulario
        }
        return render(request, 'academia/formulario-ficha.html', context)

def listar_ficha(request, ficha_id):
    return render(request, 'academia/ficha.html', {'ficha':FichaTreino.objects.get(id=ficha_id)})

