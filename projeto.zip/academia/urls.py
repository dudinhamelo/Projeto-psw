from django.urls import path, include
from .views import *


urlpatterns = [
    path('criar-equipamentos/', criar_equipamentos, name="criar-equipamentos"),
    path('detalhes-equipamentos/<int:equipamento_id>/', list_equipamentos, name="list-equipamentos" ),
    path('listar-ficha/<int:ficha_id>/', listar_ficha, name="list-ficha")
]