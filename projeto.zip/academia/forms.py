from django import forms
from .models import Equipamentos, FichaTreino

class EquipamentosForm(forms.ModelForm):
    class Meta:
        model = Equipamentos
        fields = ['nome', 'num_identificacao', 'foto']
        

class FichaForm(forms.ModelForm):
    class Meta:
        model = FichaTreino
        fields = ['nome_exercicio', 'qtd_series', 'equipamento']

