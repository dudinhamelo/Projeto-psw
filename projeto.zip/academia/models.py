from distutils.command.upload import upload
from tkinter import N
from django.db import models
from conta.models import Aluno

# Create your models here.

class Equipamentos(models.Model):
    nome = models.CharField(max_length=255)
    num_identificacao = models.IntegerField()
    foto = models.CharField(max_length=100)
    
    def __str__(self) -> str:
        return self.nome

class FichaTreino(models.Model):
    nome_exercicio = models.CharField(max_length=255)
    qtd_series = models.IntegerField()
    equipamento = models.ForeignKey(Equipamentos, on_delete=models.CASCADE, null=True)
    aluno = models.ForeignKey(Aluno, on_delete=models.CASCADE, null=True)
